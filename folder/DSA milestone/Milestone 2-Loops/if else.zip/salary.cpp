/* A company decided to give bonus of 5% to employee if his/her year of service is more than 5 years.
Ask user for their salary and year of service and print the net bonus amount. */

#include<iostream>
using namespace std;
int main()
{
int year,salary;
cout<<"Enter the years of services:"<<endl;
cin>>year;
cout<<"Enter the salary:"<<endl;
cin>>salary;

if(year>5)
{
cout<<"Your salary with bonus amount (in Rs):"<<(salary+(salary)*5/100);
}
else
{
cout<<"No extra bonus and your salary (in Rs):"<<salary;
}
return 0;
}
