/* Take input of age of 3 people by user and determine oldest and youngest among them.*/

#include<iostream>
using namespace std;

int main()
{
int age1,age2,age3;

cout<<"Enter the age of 1st person:"<<endl;
cin>>age1;
cout<<"Enter the age of 2nd person:"<<endl;
cin>>age2;
cout<<"Enter the age of 3rd person:"<<endl;
cin>>age3;

if(age1>age2&&age1>age3)
cout<<"The  oldest age is:"<<age1<<endl;
else if(age2>age1&&age2>age3)
cout<<"The oldest age is:"<<age2<<endl;
else
cout<<"The oldest age is:"<<age3<<endl;

if(age1<age2&&age1<age3)
cout<<"The  youngest age is:"<<age1;
else if(age2<age1&&age2<age3)
cout<<"The youngest age is:"<<age2;
else
cout<<"The youngest age is:"<<age3;
return 0;
}
