/* Write a program to print absolute vlaue of a number entered by user. E.g.-
INPUT: 1        OUTPUT: 1
INPUT: -1        OUTPUT: 1 */

#include<iostream>
using namespace std;

int main()
{
int num;
cout<<"INPUT:";
cin>>num;
if(num<0)
cout<<"OUTPUT:"<<((-1)*num);
else
cout<<"OUTPUT:"<<num;
return 0;
}
