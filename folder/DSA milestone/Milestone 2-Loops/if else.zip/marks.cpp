/* A school has following rules for grading system:
a. Below 25 - F
b. 25 to 45 - E
c. 45 to 50 - D
d. 50 to 60 - C
e. 60 to 80 - B
f. Above 80 - A
Ask user to enter marks and print the corresponding grade. */

#include<iostream>
using namespace std;
int main()
{
int marks;
cout<<"Enter marks (max. marks is 100):";
cin>>marks;
if(marks>=80)
cout<<"A";
else if((60<=marks)&&(marks<80))
cout<<"B";
else if((50<=marks)&&(marks<60))
cout<<"C";
else if((45<=marks)&&(marks<50))
cout<<"D";
else if((25<=marks)&&(marks<45))
cout<<"E";
else
cout<<"F";
return 0;
}
