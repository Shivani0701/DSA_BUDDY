/*A shop will give discount of 10% if the cost of purchased quantity is more than 1000.
Ask user for quantity
Suppose, one unit will cost 100.
Judge and print total cost for user.*/


#include<iostream>
using namespace std;

int main()
{
int quan;

cout<<"Enter the quantity:";
cin>>quan;
if((quan*100)>1000)
{
cout<<" You get discount and your total cost:"<<(quan*100)-(10*(quan*100)/100);
}
else
{
cout<<"No discount and total cost:"<<100*quan;
}
return 0;
}
