/* A student will not be allowed to sit in exam if his/her attendence is less than 75%.
Take following input from user
Number of classes held
Number of classes attended.
And print
percentage of class attended
Is student is allowed to sit in exam or not. */

#include<iostream>
using namespace std;

int main()
{
int held,attended,perc;

cout<<"Enter the numbers of classes held:"<<endl;
cin>>held;
cout<<"Enter the numbers of classes attended:";
cin>>attended;
perc=(attended/held)*100;
cout<<"Percentage of class attended:"<<perc<<endl;
if(perc>75)
cout<<"you are allowed to sit in exam";
else
cout<<"you are not allowed to sit in exam";
return 0;
}
