/*  A student will not be allowed to sit in exam if his/her attendence is less than 75%.
Take following input from user
Number of classes held
Number of classes attended.
And print
percentage of class attended
Is student is allowed to sit in exam or not and allow student to sit if he/she has medical cause.
ask user if he/she has medical cause or not ( 'Y' or 'N' ) and print accordingly. */

#include<iostream>
using namespace std;

int main()
{

cout<<"Medical Cause (Y OR N):";
cin>>}
if(medical_cause==Y)
cout<<""
